// AuthContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api'; // Import your API module

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('token'));
  const [user, setUser] = useState(null);

  const fetchUser = async () => {
    try {
      console.log('Fetching user...');
      const response = await api.get('/user/profile', {
        headers: {
          'x-auth-token': localStorage.getItem('token'),
        },
      });

      console.log('User response:', response.data);

      // Return the user data
      return response.data;
    } catch (error) {
      console.error('Error fetching user:', error);
      return null;
    }
  };

  const login = async () => {
    // Perform login logic, and set isAuthenticated to true
    setIsAuthenticated(true);

    console.log('Token before fetching user:', localStorage.getItem('token'));

    // Fetch and set user information
    const userData = await fetchUser();
    setUser(userData);
    console.log(userData)
  };

  const logout = () => {
    // Perform logout logic, and set isAuthenticated to false
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    setUser(null);
  };

  useEffect(() => {
    // On component mount, check if the user is authenticated and fetch user data
    if (isAuthenticated) {
      fetchUser().then((userData) => {
        setUser(userData);
      });
    }
  }, [isAuthenticated]);

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
