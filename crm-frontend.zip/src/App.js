// // src/App.js
// import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import Home from './pages/Home';
// import Login from './pages/Login';
// import Register from './pages/Register';
// import Dashboard from './pages/Dashboard';

// const App = () => {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="/login" element={<Login />} />
//         <Route path="/register" element={<Register />} />
//         <Route path="/dashboard" element={<Dashboard />} />
//       </Routes>
//     </Router>
//   );
// };

// export default App;


// // src/App.js
// import React from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Home from './pages/Home';
// import Dashboard from './pages/Dashboard';
// import Login from './pages/Login';
// import Register from './pages/Register';
// import Layout from './components/Layout.js';
// // import Layout from './components/layout';

// const App = () => {
//   // Check if the user is authenticated based on the presence of a token in local storage
  // const isAuthenticated = !!localStorage.getItem('token');

//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<Layout isAuthenticated={isAuthenticated}><Home /></Layout>} />
//         <Route path="/dashboard" element={<Layout isAuthenticated={isAuthenticated}><Dashboard /></Layout>} />
//         <Route path="/login" element={<Layout isAuthenticated={isAuthenticated}><Login /></Layout>} />
//         <Route path="/register" element={<Layout isAuthenticated={isAuthenticated}><Register /></Layout>} />
//       </Routes>
//     </Router>
//   );
// };

// export default App;

// src/App.js
// import React from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Home from './pages/Home';
// import Dashboard from './pages/Dashboard';
// import Login from './pages/Login';
// import Register from './pages/Register';
// import Layout from './components/Layout';
// import { AuthProvider } from './context/AuthContext';
// import { useNavigate } from 'react-router-dom';

// const App = () => {
//   return (
//     <AuthProvider>
//       <Router>
//         <Routes>
//           <Route path="/" element={<Layout><Home /></Layout>} />
//           <Route
//             path="/dashboard"
//             element={isAuthenticated ? <Layout><Dashboard /></Layout> : <Navigate to="/login" />}
//           />
//           {/* <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} /> */}
//           <Route path="/login" element={<Layout><Login /></Layout>} />
//           <Route path="/register" element={<Layout><Register /></Layout>} />
//         </Routes>
//       </Router>
//     </AuthProvider>
//   );
// };

// export default App;


// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import Layout from './components/Layout';
import { AuthProvider, useAuth } from './context/AuthContext';
import AddAdmin from './pages/AddAdmin';
import Vouchers from './pages/Vouchers';

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout><Home /></Layout>} />
          <Route path="/dashboard" element={<ProtectedRoute component={<Layout><Dashboard /></Layout>} />} />
          <Route path="/addadmin" element={<ProtectedRoute component={<Layout><AddAdmin /></Layout>} />} />
          <Route path="/vouchers" element={<ProtectedRoute component={<Layout><Vouchers /></Layout>} />} />
          <Route path="/login" element={<Layout><Login /></Layout>} />
          <Route path="/register" element={<Layout><Register /></Layout>} />
        </Routes>
      </Router>
    </AuthProvider>
  );
};

// A helper component for handling protected routes
const ProtectedRoute = ({ component }) => {
  const { isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return component;
  } else {
    // Redirect to the login page if not authenticated
    return <Navigate to="/login" />;
  }
};

export default App;
