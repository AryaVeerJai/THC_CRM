// src/components/Sidebar.js
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import styled from 'styled-components';

const SidebarWrapper = styled.div`
  margin-top: 60px;
  width: 200px;
  height: 100vh;
  background-color: #333;
  color: #fff;
  padding: 20px;
  position: fixed;
  top: 0;
  left: 0;
`;

const SidebarLink = styled(Link)`
  display: block;
  color: #fff;
  text-decoration: none;
  margin-bottom: 10px;
  font-size: 16px;

  &:hover {
    text-decoration: underline;
  }
`;

const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching the authentication status (replace with your actual authentication logic)
    const fetchAuthenticationStatus = async () => {
      // Placeholder for checking user authentication based on a token
      const token = localStorage.getItem('token');
      const authenticated = !!token;

      setIsAuthenticated(authenticated);
      setLoading(false);
    };

    fetchAuthenticationStatus();
  }, []);

  const handleLogout = () => {
    // Remove the authentication token from local storage
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    // Redirect to the login page
    window.location.reload('/')
    // navigate('/');
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <SidebarWrapper>
      <SidebarLink to="/" isActive={() => location.pathname === '/'}>
        Home
      </SidebarLink>
      <SidebarLink to="/dashboard" isActive={() => location.pathname === '/dashboard'}>
        Dashboard
      </SidebarLink>
      {isAuthenticated ? (
        <>
        <SidebarLink to="/addadmin">
          Add Admin
        </SidebarLink>
        <SidebarLink to="/vouchers">
          Vouchers
        </SidebarLink>
        <SidebarLink onClick={handleLogout}>
          Logout
        </SidebarLink>
        </>
      ) : (
        <>
          <SidebarLink to="/login" isActive={() => location.pathname === '/login'}>
            Login
          </SidebarLink>
          <SidebarLink to="/register" isActive={() => location.pathname === '/register'}>
            Register
          </SidebarLink>
        </>
      )}
    </SidebarWrapper>
  );
};

export default Sidebar;
