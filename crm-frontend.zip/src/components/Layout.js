// src/components/Layout.js
import React from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

const Layout = ({ children, isAuthenticated }) => {
  return (
    <>
    <Topbar isAuthenticated={isAuthenticated} />
    <div style={{ display: 'flex' }}>
      <Sidebar isAuthenticated={isAuthenticated} />
      <div style={{ marginLeft: '240px', padding: '20px', width: "100%" }}>
        {/* Content of the page goes here */}
        {children}
      </div>
    </div>
    </>
  );
};

export default Layout;
