// src/components/Auth/RegisterForm.js
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import api from '../../services/api';
import styled from 'styled-components';

const FormWrapper = styled.form`
  max-width: 300px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
`;

const Input = styled.input`
  width: 100%;
  padding: 8px;
  font-size: 14px;
  border: 1px solid #ddd;
  border-radius: 3px;
`;

const Button = styled.button`
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 3px;
  cursor: pointer;
`;

const RegisterForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [formData, setFormData] = useState({ username: '', email: '', password: '' });

  useEffect(() => {
    // Check if the user is already authenticated (e.g., has a valid token)
    // If yes, redirect to the dashboard
    const token = localStorage.getItem('token');
    if (token) {
      navigate('/dashboard');
    }
  }, [navigate, location]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/register', formData);
      const { token, user } = response.data;

      // Save the token in localStorage
      localStorage.setItem('token', token);

      // Redirect to the dashboard
      navigate('/dashboard');
    } catch (error) {
      console.error('Registration error:', error);
      // Handle registration error, e.g., display an error message to the user
    }
  };

  return (
    <FormWrapper onSubmit={handleRegister}>
      <FormGroup>
        <Label>Username:</Label>
        <Input type="text" name="username" value={formData.username} onChange={handleInputChange} required />
      </FormGroup>

      <FormGroup>
        <Label>Email:</Label>
        <Input type="email" name="email" value={formData.email} onChange={handleInputChange} required />
      </FormGroup>

      <FormGroup>
        <Label>Password:</Label>
        <Input type="password" name="password" value={formData.password} onChange={handleInputChange} required />
      </FormGroup>

      <Button type="submit">Register</Button>
    </FormWrapper>
  );
};

export default RegisterForm;
