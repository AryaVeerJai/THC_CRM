// import * as React from 'react';
// import Table from '@mui/material/Table';
// import TableBody from '@mui/material/TableBody';
// import TableCell from '@mui/material/TableCell';
// import TableContainer from '@mui/material/TableContainer';
// import TableHead from '@mui/material/TableHead';
// import TableRow from '@mui/material/TableRow';
// import Paper from '@mui/material/Paper';

// function createData(name, calories, fat, carbs, protein) {
//   return { name, calories, fat, carbs, protein };
// }

// const rows = [
//   createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//   createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
//   createData('Eclair', 262, 16.0, 24, 6.0),
//   createData('Cupcake', 305, 3.7, 67, 4.3),
//   createData('Gingerbread', 356, 16.0, 49, 3.9),
// ];

// export default function BasicTable() {
//   return (
//     <TableContainer component={Paper}>
//       <Table sx={{ minWidth: 650 }} aria-label="simple table">
//         <TableHead>
//           <TableRow>
//             <TableCell>Dessert (100g serving)</TableCell>
//             <TableCell align="right">Calories</TableCell>
//             <TableCell align="right">Fat&nbsp;(g)</TableCell>
//             <TableCell align="right">Carbs&nbsp;(g)</TableCell>
//             <TableCell align="right">Protein&nbsp;(g)</TableCell>
//           </TableRow>
//         </TableHead>
//         <TableBody>
//           {rows.map((row) => (
//             <TableRow
//               key={row.name}
//               sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
//             >
//               <TableCell component="th" scope="row">
//                 {row.name}
//               </TableCell>
//               <TableCell align="right">{row.calories}</TableCell>
//               <TableCell align="right">{row.fat}</TableCell>
//               <TableCell align="right">{row.carbs}</TableCell>
//               <TableCell align="right">{row.protein}</TableCell>
//             </TableRow>
//           ))}
//         </TableBody>
//       </Table>
//     </TableContainer>
//   );
// }

import * as React from 'react';
import Box from '@mui/joy/Box';
import Card from '@mui/joy/Card';
import CardContent from '@mui/joy/CardContent';
import Typography from '@mui/joy/Typography';
import SvgIcon from '@mui/joy/SvgIcon';
import { styled } from '@mui/material/styles';
// import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
// import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function ColorInversionSurface() {

  const [vouchers, setVouchers] = React.useState([]);

  React.useEffect(() => {
    // Fetch vouchers when the component mounts
    fetchVouchers();
  }, []);

  const fetchVouchers = async () => {
    try {
      const response = await fetch('http://localhost:8001/api/vouchers');
      const data = await response.json();

      setVouchers(data.vouchers);
      console.log(data.vouchers)
    } catch (error) {
      console.error('Error fetching vouchers:', error);
    }
  };

  const creditCard = (
    <div style={{display: "flex", gap:"10px"}} className="carddetails">
    {
      vouchers.map((element, index) => (
        <Card
      size="lg"
      variant="solid"
      color="warning"
      invertedColors
      sx={{ gap: 2, minWidth: 360, boxShadow: 'md' }}
    >
      <CardContent orientation="horizontal">
        <div>
          <Typography level="title-lg">{element.voucherCode}</Typography>
          <Typography fontSize="xs" fontFamily="code">
            Voucher Code
          </Typography>
        </div>
        <SvgIcon sx={{ ml: 'auto' }}>
          <svg
            width="50"
            height="39"
            viewBox="0 0 50 39"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M16.4992 2H37.5808L22.0816 24.9729H1L16.4992 2Z"
              fill="currentColor"
            />
            <path
              d="M17.4224 27.102L11.4192 36H33.5008L49 13.0271H32.7024L23.2064 27.102H17.4224Z"
              fill="#312ECB"
            />
          </svg>
        </SvgIcon>
      </CardContent>
      <Typography level="title-lg" fontFamily="code">
        {/* •••• •••• •••• 1212 */}
        {element.email}
      </Typography>
      <Typography level="title-lg" fontFamily="code">
        {/* •••• •••• •••• 1212 */}
        {element.phone}
      </Typography>
      <CardContent orientation="horizontal" sx={{ justifyContent: 'space-between' }}>
        <div>
          <Typography fontSize="xs" fontFamily="code">
            CARD NAME
          </Typography>
          <Typography level="title-sm" fontSize="sm">
            {element.name}
          </Typography>
        </div>
        <div>
          <Typography fontSize="xs" textAlign="right" fontFamily="code">
            CREATED
          </Typography>
          <Typography level="title-sm" fontSize="sm" textAlign="right">
            {element.createdDate}
          </Typography>
        </div>
        <div>
          <Typography fontSize="xs" textAlign="right" fontFamily="code">
            EXPIRE
          </Typography>
          <Typography level="title-sm" fontSize="sm" textAlign="right">
            {element.expiryDate}
          </Typography>
        </div>
      </CardContent>
      <CardContent orientation="horizontal" sx={{ justifyContent: 'space-between' }}>
        <div>
          <Typography fontSize="xs" fontFamily="code">
            CREATED BY
          </Typography>
          <Typography level="title-sm" fontSize="sm">
            {element.name}
          </Typography>
        </div>
        <div>
          <Typography fontSize="xs" textAlign="right" fontFamily="code">
            STATUS
          </Typography>
          <Typography level="title-sm" fontSize="sm" textAlign="right">
            {element.status}
          </Typography>
        </div>
        <div>
          <Typography fontSize="xs" textAlign="right" fontFamily="code">
            ACTION
          </Typography>
          <Typography level="title-sm" fontSize="sm" textAlign="right">
            View || Edit
          </Typography>
        </div>
      </CardContent>
    </Card>
      ))
      

    }
    </div>
    // <Card
    //   size="lg"
    //   variant="solid"
    //   color="warning"
    //   invertedColors
    //   sx={{ gap: 2, minWidth: 360, boxShadow: 'md' }}
    // >
    //   <CardContent orientation="horizontal">
    //     <div>
    //       <Typography level="title-lg">66SR8N</Typography>
    //       <Typography fontSize="xs" fontFamily="code">
    //         Voucher Code
    //       </Typography>
    //     </div>
    //     <SvgIcon sx={{ ml: 'auto' }}>
    //       <svg
    //         width="50"
    //         height="39"
    //         viewBox="0 0 50 39"
    //         fill="none"
    //         xmlns="http://www.w3.org/2000/svg"
    //       >
    //         <path
    //           d="M16.4992 2H37.5808L22.0816 24.9729H1L16.4992 2Z"
    //           fill="currentColor"
    //         />
    //         <path
    //           d="M17.4224 27.102L11.4192 36H33.5008L49 13.0271H32.7024L23.2064 27.102H17.4224Z"
    //           fill="#312ECB"
    //         />
    //       </svg>
    //     </SvgIcon>
    //   </CardContent>
    //   <Typography level="title-lg" fontFamily="code">
    //     {/* •••• •••• •••• 1212 */}
    //     Jai@gmail.com
    //   </Typography>
    //   <Typography level="title-lg" fontFamily="code">
    //     {/* •••• •••• •••• 1212 */}
    //     7544087084
    //   </Typography>
    //   <CardContent orientation="horizontal" sx={{ justifyContent: 'space-between' }}>
    //     <div>
    //       <Typography fontSize="xs" fontFamily="code">
    //         CARD NAME
    //       </Typography>
    //       <Typography level="title-sm" fontSize="sm">
    //         JOHN DOE
    //       </Typography>
    //     </div>
    //     <div>
    //       <Typography fontSize="xs" textAlign="right" fontFamily="code">
    //         CREATED
    //       </Typography>
    //       <Typography level="title-sm" fontSize="sm" textAlign="right">
    //         07/25
    //       </Typography>
    //     </div>
    //     <div>
    //       <Typography fontSize="xs" textAlign="right" fontFamily="code">
    //         EXPIRE
    //       </Typography>
    //       <Typography level="title-sm" fontSize="sm" textAlign="right">
    //         07/25
    //       </Typography>
    //     </div>
    //   </CardContent>
    //   <CardContent orientation="horizontal" sx={{ justifyContent: 'space-between' }}>
    //     <div>
    //       <Typography fontSize="xs" fontFamily="code">
    //         CREATED BY
    //       </Typography>
    //       <Typography level="title-sm" fontSize="sm">
    //         JOHN DOE
    //       </Typography>
    //     </div>
    //     <div>
    //       <Typography fontSize="xs" textAlign="right" fontFamily="code">
    //         STATUS
    //       </Typography>
    //       <Typography level="title-sm" fontSize="sm" textAlign="right">
    //         Active
    //       </Typography>
    //     </div>
    //     <div>
    //       <Typography fontSize="xs" textAlign="right" fontFamily="code">
    //         ACTION
    //       </Typography>
    //       <Typography level="title-sm" fontSize="sm" textAlign="right">
    //         View || Edit
    //       </Typography>
    //     </div>
    //   </CardContent>
    // </Card>
  );

  return (
    // <Box sx={{ display: 'flex', gap: 2 }}>
    //   {creditCard}
    //   {React.cloneElement(creditCard, { variant: 'soft' })}
    //   {React.cloneElement(creditCard, { variant: 'soft' })}
    //   {React.cloneElement(creditCard, { variant: 'soft' })}
    // </Box>
    // <Grid container spacing={{ xs: 2, md: 3 }}>
    // {/* {Array.from(Array(6)).map((_, index) => ( */}
    //   {/* <Grid> */}
    //     {/* {creditCard} */}
    //     {/* {React.cloneElement(creditCard, { variant: 'soft' })}
    //     {React.cloneElement(creditCard, { variant: 'soft' })}
    //     {React.cloneElement(creditCard, { variant: 'soft' })} */}
    //     {/* <Item>xs=2</Item> */}
    //   {/* </Grid> */}
    // {/* ))} */}
  // </Grid>
  <Box sx={{ width: 1 }}>
    <div>
        <h1>Vouchers</h1>
        </div>
      <Box display="grid" gridTemplateColumns="repeat(12, 1fr)" gap={2}>
        <Box gridColumn="span 4">
          {creditCard}
        </Box>
        {/* <Box gridColumn="span 4">
          {React.cloneElement(creditCard, { variant: 'soft' })}
        </Box>
        <Box gridColumn="span 4">
          {React.cloneElement(creditCard, { variant: 'soft' })}
        </Box>
        <Box gridColumn="span 4">
          {React.cloneElement(creditCard, { variant: 'soft' })}
        </Box> */}
      </Box>
    </Box>
  );
}