// src/pages/Home.js
import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      <h2>Welcome to The Holidays Club CRM</h2>
      <p>
        Go to <Link to="/login">Login</Link> or <Link to="/register">Register</Link>
      </p>
    </div>
  );
};

export default Home;
