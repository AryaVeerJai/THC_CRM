// AddAdmin.js
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api'; // Assuming this is your old API file

const AddAdmin = () => {
  const { isAuthenticated, user, login, logout } = useAuth();
  console.log(user)
  const [newAdminData, setNewAdminData] = useState({
    name: '',
    email: '',
    phoneNumber: '',
  });

  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    console.log({ isAuthenticated, user });
    // Check if the user is authenticated and is a superuser
    if (isAuthenticated && user && user.role === 'superuser') {
      setShowForm(true);
    } else {
      setShowForm(false);
    }
  }, [isAuthenticated, user]);

  const handleAddAdmin = async () => {
    try {
      // Check if the user is authenticated and is a superuser before making the API request
      if (isAuthenticated && user && user.role === 'superuser') {
        // Call the API to add a new admin
        await api.post('/admin/add-admin', newAdminData, {
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': localStorage.getItem('token'),
          },
        });

        // Reset the form after adding admin
        setNewAdminData({
          name: '',
          email: '',
          phoneNumber: '',
        });

        alert('Admin added successfully!');
      } else {
        alert('You don\'t have permission to add another admin.');
      }
    } catch (error) {
      console.error('Error adding admin:', error);
      alert('Failed to add admin. Please try again.');
    }
  };

  return (
    <div>
      {showForm ? (
        <>
          <h2>Add Admin</h2>
          <label>Name:</label>
          <input type="text" value={newAdminData.name} onChange={(e) => setNewAdminData({ ...newAdminData, name: e.target.value })} />
          <label>Email:</label>
          <input type="email" value={newAdminData.email} onChange={(e) => setNewAdminData({ ...newAdminData, email: e.target.value })} />
          <label>Phone Number:</label>
          <input type="text" value={newAdminData.phoneNumber} onChange={(e) => setNewAdminData({ ...newAdminData, phoneNumber: e.target.value })} />
          <button onClick={handleAddAdmin}>Add Admin</button>
        </>
      ):<>
      <p>YOu Dont have Permission to Add Admin</p>
      </>
      }
    </div>
  );
};

export default AddAdmin;
