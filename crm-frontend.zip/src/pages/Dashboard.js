// Dashboard.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Check if the user is authenticated
  if (!isAuthenticated) {
    // Redirect to the login page if not authenticated
    navigate('/login');
    return null; // You can also render a loading message or another component while redirecting
  }

  // Render the dashboard content for authenticated users
  return (
    <div>
      <h2>Dashboard</h2>
      Add your dashboard content here
    </div>
  );
};

export default Dashboard;
