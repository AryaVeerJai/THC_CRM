// // src/services/api.js
// import axios from 'axios';

// const api = axios.create({
//   baseURL: 'http://localhost:8001/api', // Update with your backend API URL
// });

// export default api;


// apiService.js
// const apiUrl = 'http://localhost:8001'; // Replace with your backend API URL

// const addAdmin = async (adminData) => {
//   const response = await fetch(`${apiUrl}/admin/add-admin`, {
//     method: 'POST',
//     headers: {
//       'Content-Type': 'application/json',
//       'x-auth-token': localStorage.getItem('token'),
//     },
//     body: JSON.stringify(adminData),
//   });

//   if (!response.ok) {
//     throw new Error('Failed to add admin');
//   }
// };

// const api = {
//   addAdmin,
// };

// export default api;

// src/services/api.js
import axios from 'axios';

const apiUrl = 'http://localhost:8001'; // Replace with your new backend API URL
const api = axios.create({
  baseURL: `${apiUrl}/api`, // Adjust the base URL based on your backend API structure
});

export default api;



