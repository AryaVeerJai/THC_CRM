// config/mailer.js
module.exports = {
    email: 'your-email@example.com',            // Update with your email address
    password: 'your-email-password',            // Update with your email password
    service: 'gmail',                           // Update with your email service (e.g., 'gmail')
  };
  