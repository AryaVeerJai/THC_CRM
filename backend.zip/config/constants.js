// config/constants.js
module.exports = {
    GLOBAL_TOKEN: 'thc#crm',
    JWT_SECRET: 'thccrmsecretkey'
  };
  