// config/db.js
module.exports = {
    mongoURI: 'mongodb://localhost/holidays_club_crm', // Update with your MongoDB connection string
  };
  