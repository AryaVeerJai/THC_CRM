// // controllers/customerController.js
// const Customer = require('../models/customer');

// exports.addCustomer = async (req, res) => {
//   // Implement logic to add a new customer
// };

// exports.getAllCustomers = async (req, res) => {
//   // Implement logic to get all customers
// };

// controllers/customerController.js
const Customer = require('../models/customer');

// Add a new customer
exports.addCustomer = async (req, res) => {
  try {
    const { name, email, phone, address } = req.body;

    // Check if the customer already exists
    const existingCustomer = await Customer.findOne({ email });
    if (existingCustomer) {
      return res.status(400).json({ message: 'Customer with this email already exists.' });
    }

    // Create a new customer
    const newCustomer = new Customer({
      name,
      email,
      phone,
      address,
    });

    // Save the customer to the database
    await newCustomer.save();

    res.status(201).json({ message: 'Customer added successfully.', customer: newCustomer });
  } catch (error) {
    console.error('Error adding customer:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

// Get all customers
exports.getAllCustomers = async (req, res) => {
  try {
    // Retrieve all customers from the database
    const customers = await Customer.find();

    res.status(200).json(customers);
  } catch (error) {
    console.error('Error getting customers:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};
