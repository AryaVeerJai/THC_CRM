// config/db.js
module.exports = {
    // mongoURI: 'mongodb://localhost/holidays_club_crm', // Update with your MongoDB connection string
    mongoURI: 'mongodb+srv://admin:adminpass@holidaysclubcrm.5nqc6zg.mongodb.net/?retryWrites=true&w=majority'
  };
  